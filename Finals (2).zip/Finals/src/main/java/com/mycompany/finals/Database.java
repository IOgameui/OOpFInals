/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author MXXGIE
 */

public class Database {
    
    public static Connection connectdb(){
     
    try{
        String url = "jdbc:mysql://localhost:3306/records";
        String user = "admin";
        String password = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection(url, user, password);
        return conn;
    }catch(SQLException | ClassNotFoundException e){
        System.out.println(e);
    }
    return null;
    }
}